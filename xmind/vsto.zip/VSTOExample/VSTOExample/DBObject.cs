﻿namespace VSTOExample
{
    public enum DBObject
    {
        /// <summary>
        /// Tabla.
        /// </summary>
        Table = 0,
        /// <summary>
        /// Función.
        /// </summary>
        Function = 1,
        /// <summary>
        /// Procedimiento almacenado.
        /// </summary>
        Procedure = 2
    }
}
