﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Tools
{
    class Macro
    {
        static public Color verColor = Color.Red;
        static public Color oriColor = Color.White;
    }
}
